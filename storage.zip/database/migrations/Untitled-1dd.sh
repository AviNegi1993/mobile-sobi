
add
requirement
client_name
address
remarks
type-   select box ['open policy','single transit']
commodity_type
mode_of_transport -> [RAIL/ROAD/AIR/SEA/COURIER/ALL]
cover_type -> [ITC A,ITC B]
sum_insured 
per_sending_limit 
per_location_limit
estimate_annual_sum
basic_of_valuation
polcicy_period
start_date
expiry_date
commodity_details [BOXES/CONTAINER /WEIGHT/NO OF PACKAGES]
packing_description
remarks
libality
policy_type
liability_industrial
liability_nonindustrial
liability_act
professional_indeminity
comprehensive_general_liability
wc_policy
pincode
industry_type
worker_number
job_profile ->[SKILLED/SEMISKILLED/UNSKILLED]
salary_per_month
add_on_cover
medical_extension
occupation_disease
compressed_air_disease
terrorism_cover
sub_contractor_cover
multiple_location
occupancy
occupancy_tarriff
particular
building
plant_machine
furniture_fixure
stock_in_process
finished_stock
other_contents
clain_in_last_three_year [yes,no]
loss_details
loss_in_amount
loss_date
measures_taken_after_loss
address_risk_location
cover_opted
policy_inception_date
tenure
construction_type
age_of_building
basement_for_building
basement_for_content
claims
building_carpet_area
building_cost_of_construction
building_sum_insured
content_sum_insured
rent_alternative_accommodation
health_type -> [individual,family]
fresh
portability 
dob
pre_existing_disease
hospitalization_history
upload_discharge_summary
dob_sr_most_member
dob_self
dob_spouse
dob_child
dob_father
dob_mother
sum_insured
visiting_country
date_of_departure
date_of_arrival
no_of_days
no_person
passport_datails
make 
model 
cubic_capacity
bussiness_type
rto 
reg_no 
mfr_year
reg_date 
claims_in_existing_policy
ncb_in_existing_policy
gcv_type [public carrier,private_carrier]
gvw [ >2500 to >40000]
fuel_type
passenger_carrying_capacity
category [school bus , route bus]
varriant











<?php

/**
 * @OA\Schema(
 *     type="string",
 *     title="Forbidden",
 *     description="Forbidden",
 * )
 */
class Forbidden
{

    /**
     * @OA\Property(
     *     title="forbidden",
     *     description="Forbidden",
     * )
     * @var string
     */
    public $forbidden;
}

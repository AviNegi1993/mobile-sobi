<?php

/**
 * @OA\Schema(
 *     type="object",
 *     title="Not found",
 *     description="Not found",
 * )
 */
class Notfound
{

    /**
     * @OA\Property(
     *     title="Not found",
     *     description="Not found",
     *
      * )
     * @var string
     */
    public $notfound;
}

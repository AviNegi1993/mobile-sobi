<?php

/**
 * @OA\Schema(
 *     type="object",
 *     title="Unauthenticated",
 *     description="Unauthenticated",
 * )
 */
class Unauthenticated
{

    /**
     * @OA\Property(
     *     title="Unauthenticated",
     *     description="Unauthenticated",
     * )
     * @var string
     */
    public $unauthenticated;
}

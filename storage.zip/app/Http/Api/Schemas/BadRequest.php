<?php

/**
 * @OA\Schema(
 *     type="string",
 *     title="Bad Request",
 *     description="BadRequest",
 * )
 */
class BadRequest
{

    /**
     * @OA\Property(
     *     title="dsfsfds",
     *     description="Bad Request"
     * )
     * @var string
     */
    public $dsfsfds;
}
